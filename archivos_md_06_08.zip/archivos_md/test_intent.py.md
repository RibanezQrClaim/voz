### .\test_intent.py

```py
from core.intent_detector import detectar_intencion

texto = "¿Qué me escribió Juan?"
print(detectar_intencion(texto))

```
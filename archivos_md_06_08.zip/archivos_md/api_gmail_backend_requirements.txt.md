### .\api_gmail_backend\requirements.txt

```txt
Flask
flask-cors
```
### .\front_end_vite\src\components\index.css

```css
@tailwind base;
@tailwind components;
@tailwind utilities;

```
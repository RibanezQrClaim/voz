### .\core\intent_detector.py

```py
import openai
import json
import re

openai.api_key = "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"
openai.api_base = "https://openrouter.ai/api/v1"

def detectar_intencion(texto_usuario, contexto=None):
    prompt = f"""
Convierte el siguiente comando de voz para Gmail en una acción JSON válida.
Responde **solo con el JSON**, sin explicaciones ni texto adicional.

Ejemplos:

"¿Cuántos correos tengo sin leer?"
→ {{"accion": "contar_no_leidos"}}

"¿Quién me escribió hoy?"
→ {{"accion": "remitentes_hoy"}}

"Resúmeme los correos de hoy"
→ {{"accion": "resumen_hoy"}}

Comando: "{texto_usuario}"
→
"""

    response = openai.ChatCompletion.create(
        model="mistralai/mistral-7b-instruct:free",
        messages=[{"role": "user", "content": prompt}],
        temperature=0
    )

    contenido = response.choices[0].message.content.strip()
    print("📦 Contenido generado por LLM:", contenido)

    # Extraer primer bloque JSON válido
    try:
        json_match = re.search(r'\{.*\}', contenido, re.DOTALL)
        if json_match:
            return json.loads(json_match.group(0))
        else:
            raise ValueError("No se encontró JSON válido")
    except Exception as e:
        print("❌ Error al interpretar JSON:", e)
        print("📦 Texto crudo:", contenido)
        return None



```
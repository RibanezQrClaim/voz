### .\front_end_vite\src\index.css

```css
@tailwind base;
@tailwind components;
@tailwind utilities;

```
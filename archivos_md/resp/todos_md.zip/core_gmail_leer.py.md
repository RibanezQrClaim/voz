### .\core\gmail\leer.py

```py
from utils.dates import get_rfc3339_today
from llm_client import resumir_texto_llm
import base64


def remitentes_hoy(service):
    """Devuelve un string con los remitentes únicos que enviaron correos hoy, uno por línea"""
    today_rfc3339 = get_rfc3339_today()
    query = f"after:{today_rfc3339} is:inbox"
    results = service.users().messages().list(userId='me', q=query, maxResults=50).execute()
    messages = results.get('messages', [])

    remitentes = set()
    for msg in messages:
        detalle = service.users().messages().get(userId='me', id=msg['id'], format='metadata', metadataHeaders=['From']).execute()
        headers = detalle.get('payload', {}).get('headers', [])
        for h in headers:
            if h['name'] == 'From':
                remitentes.add(h['value'])

    if not remitentes:
        return "No recibiste correos hoy."

    def limpiar_remitente(r):
        if "<" in r:
            return r.split("<")[0].strip()
        return r.strip()

    nombres_limpios = [limpiar_remitente(r) for r in remitentes]
    nombres_limpios.sort()

    return "\n".join(nombres_limpios)


def resumen_correos_hoy(service, cantidad=5):
    """Devuelve un resumen LLM de los correos de hoy (remitente, asunto y resumen del cuerpo)"""
    today_rfc3339 = get_rfc3339_today()
    query = f"after:{today_rfc3339} is:inbox"
    results = service.users().messages().list(userId='me', q=query, maxResults=cantidad).execute()
    messages = results.get('messages', [])

    if not messages:
        return "No tienes correos nuevos hoy."

    resumenes = []
    for msg in messages:
        detalle = service.users().messages().get(userId='me', id=msg['id'], format='full').execute()
        headers = detalle['payload'].get('headers', [])
        remitente = next((h['value'] for h in headers if h['name'] == 'From'), '(Desconocido)')
        asunto = next((h['value'] for h in headers if h['name'] == 'Subject'), '(Sin asunto)')

        # Extraer texto del cuerpo
        cuerpo = ""
        if 'parts' in detalle['payload']:
            for part in detalle['payload']['parts']:
                if part.get('mimeType') == 'text/plain' and 'data' in part['body']:
                    cuerpo = base64.urlsafe_b64decode(part['body']['data']).decode("utf-8", errors="ignore")
                    break

        if not cuerpo:
            cuerpo = detalle.get('snippet', '(Sin contenido)')

        resumen = resumir_texto_llm(cuerpo)
        resumenes.append(f"{remitente}\n\"{asunto}\"\n{resumen}\n-----")

    return "\n".join(resumenes)


def contar_correos_no_leidos(service):
    """Cuenta la cantidad de correos no leídos en la bandeja de entrada."""
    query = "is:unread in:inbox"
    results = service.users().messages().list(userId='me', q=query).execute()
    mensajes = results.get('messages', [])

    if not mensajes:
        return 0
    return len(mensajes)


```
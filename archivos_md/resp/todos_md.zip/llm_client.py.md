### .\llm_client.py

```py
# llm_client.py

def resumir_texto_llm(texto):
    """
    Simula un resumen del cuerpo del correo usando LLM.
    Más adelante puedes reemplazar esta función por una llamada real al modelo.
    """
    if not texto:
        return "(Sin contenido)"
    
    # Simulación simple: primeros 100 caracteres
    resumen = texto.strip().replace('\n', ' ')
    return resumen[:100] + ("..." if len(resumen) > 100 else "")

```
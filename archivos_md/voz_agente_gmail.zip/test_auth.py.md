### .\test_auth.py

```py
from interfaces.gmail_api import autenticar_gmail

autenticar_gmail()
print("✅ Autenticación completada")

```
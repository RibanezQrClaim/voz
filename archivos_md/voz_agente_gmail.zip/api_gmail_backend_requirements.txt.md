### .\api_gmail_backend\requirements.txt

```txt
Flask
Flask-Cors
google-api-python-client
google-auth
google-auth-oauthlib
google-auth-httplib2
openai
requests
python-dotenv
whisper
SpeechRecognition
pydub

```